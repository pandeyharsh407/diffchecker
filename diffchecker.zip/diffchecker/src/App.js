import React, { useState } from 'react';
import { computeLineDiffs } from './utils/diffUtils';
import { computeWordDiffs } from './utils/wordDiffUtils';  // Import word diff function

function App() {
  const [originalCode, setOriginalCode] = useState('');
  const [modifiedCode, setModifiedCode] = useState('');
  const [diffs, setDiffs] = useState([]);
  const [compareClicked, setCompareClicked] = useState(false);

  const handleCompare = () => {
    const result = computeLineDiffs(originalCode, modifiedCode);
    setDiffs(result);
    setCompareClicked(true);
  };

  const handleClear = () => {
    setOriginalCode('');
    setModifiedCode('');
    setDiffs([]);
    setCompareClicked(false);
  };

  // word-level diffs
  const getWordDiffs = (originalLine, modifiedLine) => {
    return computeWordDiffs(originalLine, modifiedLine).map(part => (
      <span
        key={part.key}
        className={`${
          part.isAdded ? 'bg-green-200' : part.isRemoved ? 'bg-red-200' : ''
        }`}
      >
        {part.word}
      </span>
    ));
  };

  // Count the additions and removals (line-based)
  const leftAdditions  = diffs.filter(d => d.originalLine && !d.modifiedLine).length;
  const rightAdditions = diffs.filter(d => !d.originalLine && d.modifiedLine).length;
  const leftRemovals   = rightAdditions;
  const rightRemovals  = leftAdditions;

  const totalOrig = originalCode.split('\n').length;
  const totalMod  = modifiedCode.split('\n').length;

  return (
    <div className="flex flex-col min-h-screen p-6 bg-gray-50">
      {/* Title */}
      <h1 className="text-4xl font-bold mb-4 text-center text-blue-700">
        Diff-checker
      </h1>

      {/* Status */}
      {compareClicked && (
        <div className="text-center mb-6">
          {diffs.some(d => d.originalLine !== d.modifiedLine) ? (
            <p className="text-red-500 text-lg font-semibold">Differences found!</p>
          ) : (
            <div className="flex flex-col items-center">
              <p className="text-green-600 text-lg font-semibold">
                The two files are identical 😊
              </p>
              <p className="text-blue-500 text-sm mt-1">
                There is no difference to show between these two files
              </p>
            </div>
          )}
        </div>
      )}

      {/* Diff Panels */}
      {compareClicked && (
        <div className="flex flex-col md:flex-row gap-6 mb-8">
          {/* Left (Original) */}
          <div className="flex-1 bg-white p-4 shadow-md rounded-md">
            <div className="flex justify-between items-center mb-4 text-sm text-gray-600">
              <span className={leftAdditions > 0 ? 'text-green-600' : 'text-red-600'}>
                {leftAdditions > 0
                  ? `${leftAdditions} Addition${leftAdditions > 1 ? 's' : ''}`
                  : `${leftRemovals} Removal${leftRemovals > 1 ? 's' : ''}`}
              </span>
              <span>Total: {totalOrig} lines</span>
              <span className={leftAdditions > 0 ? 'text-red-600' : 'text-green-600'}>
                {leftAdditions > 0
                  ? `${leftRemovals} Removal${leftRemovals > 1 ? 's' : ''}`
                  : `${leftAdditions} Addition${leftAdditions > 1 ? 's' : ''}`}
              </span>
            </div>
            <div className="space-y-1">
              {diffs.map((d, i) => (
                <div
                  key={i}
                  className={`flex items-center ${
                    d.originalLine !== d.modifiedLine ? 'bg-red-50' : ''
                  } p-1 rounded`}
                >
                  <div className="flex items-center font-mono text-sm text-gray-500">
                    <span className="w-8 text-right">{d.line}</span>
                    <span className="px-2 text-gray-400">|</span>
                  </div>
                  <pre className="flex-1 font-mono text-sm whitespace-pre-wrap">
                    {getWordDiffs(d.originalLine, d.modifiedLine)}
                  </pre>
                </div>
              ))}
            </div>
          </div>

          {/* Right (Modified) */}
          <div className="flex-1 bg-white p-4 shadow-md rounded-md">
            <div className="flex justify-between items-center mb-4 text-sm text-gray-600">
              <span className={rightAdditions > 0 ? 'text-green-600' : 'text-red-600'}>
                {rightAdditions > 0
                  ? `${rightAdditions} Addition${rightAdditions > 1 ? 's' : ''}`
                  : `${rightRemovals} Removal${rightRemovals > 1 ? 's' : ''}`}
              </span>
              <span>Total: {totalMod} lines</span>
              <span className={rightAdditions > 0 ? 'text-red-600' : 'text-green-600'}>
                {rightAdditions > 0
                  ? `${rightRemovals} Removal${rightRemovals > 1 ? 's' : ''}`
                  : `${rightAdditions} Addition${rightAdditions > 1 ? 's' : ''}`}
              </span>
            </div>
            <div className="space-y-1">
              {diffs.map((d, i) => (
                <div
                  key={i}
                  className={`flex items-center ${
                    d.modifiedLine !== d.originalLine ? 'bg-green-50' : ''
                  } p-1 rounded`}
                >
                  <div className="flex items-center font-mono text-sm text-gray-500">
                    <span className="w-8 text-right">{d.line}</span>
                    <span className="px-2 text-gray-400">|</span>
                  </div>
                  <pre className="flex-1 font-mono text-sm whitespace-pre-wrap">
                    {getWordDiffs(d.originalLine, d.modifiedLine)}
                  </pre>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Input Areas */}
      <div className="flex flex-col md:flex-row gap-6 mb-6">
        <div className="flex-1 flex flex-col">
          <h3 className="text-lg font-medium mb-2">Original Code</h3>
          <textarea
            className="flex-1 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 min-h-[150px]"
            value={originalCode}
            onChange={e => setOriginalCode(e.target.value)}
            placeholder="Paste original code here..."
          />
        </div>
        <div className="flex-1 flex flex-col">
          <h3 className="text-lg font-medium mb-2">Modified Code</h3>
          <textarea
            className="flex-1 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-400 min-h-[150px]"
            value={modifiedCode}
            onChange={e => setModifiedCode(e.target.value)}
            placeholder="Paste modified code here..."
          />
        </div>
      </div>

      {/* Buttons */}
      <div className="flex justify-center gap-6">
        <button
          onClick={handleCompare}
          className="bg-blue-500 text-white px-8 py-2 rounded hover:bg-blue-600 transition"
        >
          Compare
        </button>
        <button
          onClick={handleClear}
          className="bg-gray-400 text-white px-8 py-2 rounded hover:bg-gray-500 transition"
        >
          Clear
        </button>
      </div>
    </div>
  );
}

export default App;
