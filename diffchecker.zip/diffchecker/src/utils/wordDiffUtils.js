import { diffWords } from 'diff';

export const computeWordDiffs = (originalLine, modifiedLine) => {
  const diff = diffWords(originalLine, modifiedLine);
  
  // Highlight the changes in words
  return diff.map((part, index) => {
    const isAdded = part.added;
    const isRemoved = part.removed;
    const word = part.value;

    return {
      word: word,
      isAdded: isAdded,
      isRemoved: isRemoved,
      key: index
    };
  });
};
