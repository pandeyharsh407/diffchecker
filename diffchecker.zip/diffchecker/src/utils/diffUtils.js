// src/utils/diffUtils.js

/**
 * Compare two multi-line strings line by line.
 * Returns an array of { line, originalLine, modifiedLine, changed }.
 */
export function computeLineDiffs(original, modified) {
    const origLines = original.split('\n');
    const modLines  = modified.split('\n');
    const max       = Math.max(origLines.length, modLines.length);
    const diffs = [];
  
    for (let i = 0; i < max; i++) {
      const o = origLines[i] ?? '';
      const m = modLines[i]  ?? '';
      const changed = o !== m;
      diffs.push({
        line: i + 1,
        originalLine: o,
        modifiedLine: m,
        changed
      });
    }
    return diffs;
  }
  