// src/components/DiffInputArea.jsx
import React from 'react';

export default function DiffInputArea({ original, modified, setOriginal, setModified }) {
  return (
    <div className="flex flex-col md:flex-row gap-6">
      {/* Original */}
      <div className="flex-1 flex flex-col">
        <label className="mb-2 font-medium text-gray-700">Original Code</label>
        <textarea
          className="flex-1 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-400 resize-none min-h-[150px] font-mono"
          value={original}
          onChange={e => setOriginal(e.target.value)}
          placeholder="Paste original code here..."
        />
      </div>
      {/* Modified */}
      <div className="flex-1 flex flex-col">
        <label className="mb-2 font-medium text-gray-700">Modified Code</label>
        <textarea
          className="flex-1 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-400 resize-none min-h-[150px] font-mono"
          value={modified}
          onChange={e => setModified(e.target.value)}
          placeholder="Paste modified code here..."
        />
      </div>
    </div>
  );
}
