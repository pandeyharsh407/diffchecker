import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-blue-600 text-white py-2 text-center mt-10">
      <p className="text-sm">&copy; {new Date().getFullYear()} Diff Checker App. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
