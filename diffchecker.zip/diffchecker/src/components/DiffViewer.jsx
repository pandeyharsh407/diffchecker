// src/components/DiffViewer.jsx
import React, { useState } from 'react';
import { computeLineDiffs } from '../utils/diffUtils';
import DiffInputArea from './DiffInputArea';

export default function DiffViewer() {
  const [original, setOriginal] = useState('');
  const [modified, setModified] = useState('');
  const [showDiff, setShowDiff]   = useState(false);

  const diffs = computeLineDiffs(original, modified);
  const removedCount = diffs.filter(d => d.changed && d.originalLine !== '').length;
  const addedCount   = diffs.filter(d => d.changed && d.modifiedLine !== '').length;
  const totalOrig    = original.split('\n').length;
  const totalMod     = modified.split('\n').length;

  const copyToClipboard = text => navigator.clipboard.writeText(text);

  const onCompare = () => setShowDiff(true);
  const onClear   = () => {
    setOriginal(''); setModified(''); setShowDiff(false);
  };

  return (
    <div className="space-y-8">
      {/* Title */}
      <h1 className="text-4xl font-bold text-center text-blue-700">Diff Checker</h1>

      {/* Status */}
      {showDiff && (
        <div className="text-center">
          {removedCount + addedCount === 0 ? (
            <span className="text-green-600 font-semibold">No differences found.</span>
          ) : (
            <span className="text-red-500 font-semibold">Differences found!</span>
          )}
        </div>
      )}

      {/* Diff Panels */}
      {showDiff && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Original Panel */}
          <div className="flex flex-col border rounded-lg bg-white shadow">
            <div className="flex items-center justify-between bg-gray-100 p-3 border-b">
              <span className="text-red-600 font-medium">{removedCount} removal{removedCount!==1 && 's'}</span>
              <span className="text-gray-600">{totalOrig} lines</span>
              <button
                onClick={() => copyToClipboard(original)}
                className="text-blue-500 hover:underline text-sm"
              >
                Copy
              </button>
            </div>
            <div className="overflow-auto p-3 max-h-[300px]">
              {diffs.map(d => (
                <div key={d.line} className={`flex ${d.changed ? 'bg-red-50' : ''}`}>
                  <div className="w-8 text-right pr-2 text-gray-400">{d.line}</div>
                  <pre className="whitespace-pre-wrap flex-1 font-mono">{d.originalLine || ''}</pre>
                </div>
              ))}
            </div>
          </div>

          {/* Modified Panel */}
          <div className="flex flex-col border rounded-lg bg-white shadow">
            <div className="flex items-center justify-between bg-gray-100 p-3 border-b">
              <span className="text-green-600 font-medium">{addedCount} addition{addedCount!==1 && 's'}</span>
              <span className="text-gray-600">{totalMod} lines</span>
              <button
                onClick={() => copyToClipboard(modified)}
                className="text-blue-500 hover:underline text-sm"
              >
                Copy
              </button>
            </div>
            <div className="overflow-auto p-3 max-h-[300px]">
              {diffs.map(d => (
                <div key={d.line} className={`flex ${d.changed ? 'bg-green-50' : ''}`}>
                  <div className="w-8 text-right pr-2 text-gray-400">{d.line}</div>
                  <pre className="whitespace-pre-wrap flex-1 font-mono">{d.modifiedLine || ''}</pre>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Input & Buttons */}
      <DiffInputArea
        original={original}
        modified={modified}
        setOriginal={setOriginal}
        setModified={setModified}
      />
      <div className="flex justify-center gap-4">
        <button
          onClick={onCompare}
          className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition"
        >
          Compare
        </button>
        <button
          onClick={onClear}
          className="bg-gray-400 text-white px-6 py-2 rounded hover:bg-gray-500 transition"
        >
          Clear
        </button>
      </div>
    </div>
  );
}
